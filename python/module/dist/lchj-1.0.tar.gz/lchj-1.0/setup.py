from distutils.core import setup

setup(name="lchj",
      version="1.0",
      description="test package",
      packages=['module1', 'module2','module1.module3'])