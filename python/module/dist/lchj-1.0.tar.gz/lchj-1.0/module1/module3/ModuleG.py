
def moduleBFunctionA():
    print "moduleBFunctionA"

def moduleBFunctionB():
    print "moduleBFunctionB"

def moduleBFunctionC():
    print "moduleBFunctionC"