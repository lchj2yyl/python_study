
def moduleCFunctionA():
    print "moduleCFunctionA"

def moduleCFunctionB():
    print "moduleCFunctionB"

def moduleCFunctionC():
    print "moduleCFunctionC"