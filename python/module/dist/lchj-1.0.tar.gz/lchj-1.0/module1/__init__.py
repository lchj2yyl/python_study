#__all__ = ['ModuleC', 'ModuleB']
import ModuleB
import ModuleC
import module3

